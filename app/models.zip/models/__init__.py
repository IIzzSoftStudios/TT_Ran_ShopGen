# app/models/__init__.py

# Import models from submodules to make them accessible directly from app.models
# The order matters for resolving ForeignKey/relationship dependencies

# Import User first as it's the most fundamental model
from .users import User

# Then import other models that might depend on User
from .backend import City, Shop, Item, ShopInventory, PriceHistory, MarketPulse, shop_cities
from .price_history_aggregated import AggregatedPriceHistory
from .users import RegistrationKey, GMProfile, Player, PlayerInventory, PlayerCharacter, CharacterEquipmentSlot, CharacterStat
from .campaigns import Campaign, CampaignPlayer
from .market import RegionalMarket, GlobalMarket, DemandModifier, ModifierTarget

# Import production models (if uncommented and used)
# from .production import ResourceNode, ProductionHistory, ResourceTransform

# Import economy models (if uncommented and used)
# from .economy import MarketEvent, PlayerInvestment, ShopMaintenance

# You might need to adjust the import order or handle specific circular dependencies
# if Flask-Migrate or SQLAlchemy throws errors during initialization.

# Define __all__ to control `from app.models import *` behavior (optional but good practice)
__all__ = [
    # users.py (most fundamental)
    'User',
    # backend.py
    'City', 'Shop', 'Item', 'ShopInventory', 'PriceHistory', 'MarketPulse', 'shop_cities', 'AggregatedPriceHistory',
    # users.py (other models)
    'RegistrationKey', 'GMProfile', 'Player', 'PlayerInventory', 'PlayerCharacter', 'CharacterEquipmentSlot', 'CharacterStat',
    # campaigns.py
    'Campaign', 'CampaignPlayer',
    # market.py
    'RegionalMarket', 'GlobalMarket', 'DemandModifier', 'ModifierTarget',
    # production.py
    # 'ResourceNode', 'ProductionHistory', 'ResourceTransform', 
    # economy.py
    # 'MarketEvent', 'PlayerInvestment', 'ShopMaintenance',
]
